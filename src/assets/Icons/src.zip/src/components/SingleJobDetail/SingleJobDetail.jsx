import React from 'react';

const SingleJobDetail = () => {
    return (
        <div>
            
        </div>
    );
};

export default SingleJobDetail;