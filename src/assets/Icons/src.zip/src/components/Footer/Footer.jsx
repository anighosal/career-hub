import React from 'react';

const Footer = () => {
    return (
        <div className='bg-gray-950'>
           <div className='grid lg:grid-cols-5 items-center gap-5'>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
           </div>
        </div>
    );
};

export default Footer;