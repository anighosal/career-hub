import React from 'react';

const AppliedJobs = () => {
    return (
        <div>
            
        </div>
    );
};

export default AppliedJobs;