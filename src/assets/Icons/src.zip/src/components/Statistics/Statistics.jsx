import React from 'react';

const Statistics = () => {
    return (
        <div>
            
        </div>
    );
};

export default Statistics;